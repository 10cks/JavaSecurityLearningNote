package com.example.employeemanagementsystem.dao;

import com.example.employeemanagementsystem.pojo.Department;
import com.example.employeemanagementsystem.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
// 员工Dao

// 在一个类上使用 @Repository 注解，Spring框架会认为这个类将涉及到数据库的操作，可能是查询数据、更新数据、或是删除数据等。
// 这样，Spring会去处理该类与数据库交互时可能存在的一些底层的问题，比如数据库连接的获取和释放、事务管理等。
@Repository
public class EmployeeDao {
    // 模拟员工的数据
    @Autowired // 自动注解
    private static Map<Integer, Employee> employees = null;
    private DepartmentDao departmentDao;
    static {    // 所有对象共享同一副本，优先加载
        employees = new HashMap<>(); // 创建一个部门表
        employees.put(1001, new Employee(1001, "AA","111@qq.com",1,new Department(101,"后勤部")));
        employees.put(1002, new Employee(1002, "BB","111@qq.com",0,new Department(101,"后勤部")));
        employees.put(1003, new Employee(1003, "CC","111@qq.com",1,new Department(101,"后勤部")));
        employees.put(1004, new Employee(1004, "DD","111@qq.com",0,new Department(101,"后勤部")));
        employees.put(1005, new Employee(1005, "EE","111@qq.com",1,new Department(101,"后勤部")));
    }
    // 主键自增
    private static Integer initId=1006;
    // 增加一个员工
    public void save(Employee employee){
        if(employee.getId()==null){
            employee.setId(initId++);
        }
        employee.setDepartment(departmentDao.getDepartmentById(employee.getDepartment().getId()));
        employees.put(employee.getId(),employee);
    }
    // 查询全部员工信息
    public Collection<Employee> getAll(){
        return employees.values();
    }
    // 通过id查询员工
    public Employee getEmployeeById(Integer id){
        return employees.get(id);
    }
    // 通过id删除员工
    public void delete(Integer id){
        employees.remove(id);
    }
}
